//! Build-only rotation grammar. No library sources or character-specific combos.
use crate::{artifact::Manifest, program::Rng};
use serde::{Deserialize, Serialize};

const MAX_VISITS: usize = 12;
const MAX_ACTIONS: usize = 12;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Command {
    pub action: String,
    pub count: u8,
    pub ready: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Field {
    pub frames: u16,
    pub pattern: Vec<Command>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Visit {
    pub actor: usize,
    pub entry: Vec<Command>,
    pub field: Option<Field>,
    pub period: u8,
    pub phase: u8,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Rotation {
    pub active: usize,
    pub opening: Vec<Visit>,
    pub cycle: Vec<Visit>,
}

/// Default action forms accepted by the engine for this actual build.
/// This does not infer resource prerequisites or enumerate action parameters.
pub struct Catalog {
    actions: Vec<Vec<String>>,
}

impl Catalog {
    pub fn new(m: &Manifest) -> Result<Self, String> {
        let context = format!(
            "{}{}active {};\n",
            crate::artifact::HEADER,
            m.build(),
            m.members[0].key
        );
        let parsed = gse::gcsl::parse(&format!("{context}wait(1);"))?;
        let unsupported = gse::check::unsupported(&parsed);
        if !unsupported.is_empty() {
            return Err(unsupported.join("; "));
        }
        let mut actions = Vec::new();
        for member in &m.members {
            let mut available = Vec::new();
            for action in ["attack", "charge", "skill", "burst", "dash", "jump"] {
                let p = gse::gcsl::parse(&format!("{context}{} {action};", member.key))?;
                if gse::check::unsupported(&p).is_empty() {
                    available.push(action.to_string());
                }
            }
            if !available.iter().any(|a| a == "attack") {
                return Err(format!(
                    "{}: generated grammar requires normal attacks",
                    member.key
                ));
            }
            actions.push(available);
        }
        Ok(Self { actions })
    }

    fn supports(&self, actor: usize, action: &str) -> bool {
        self.actions[actor].iter().any(|a| a == action)
    }

    fn command(&self, actor: usize, rng: &mut Rng) -> Command {
        let action = &self.actions[actor][rng.index(self.actions[actor].len())];
        command(action, rng)
    }

    fn visit(&self, actor: usize, rng: &mut Rng, field: bool) -> Visit {
        let mut entry = Vec::new();
        for action in ["skill", "burst"] {
            if self.supports(actor, action) && rng.index(4) != 0 {
                entry.push(command(action, rng));
            }
        }
        if rng.index(2) == 0 {
            entry.reverse();
        }
        if entry.is_empty() || rng.index(3) == 0 {
            entry.push(command("attack", rng));
        }
        Visit {
            actor,
            entry,
            field: field.then(|| self.field(actor, rng)),
            period: if rng.index(4) == 0 { 2 } else { 1 },
            phase: 0,
        }
    }

    fn field(&self, actor: usize, rng: &mut Rng) -> Field {
        let mut pattern = vec![command("attack", rng)];
        if rng.index(2) == 0 {
            pattern.push(self.command(actor, rng));
        }
        Field {
            frames: [180, 300, 480, 600, 900][rng.index(5)],
            pattern,
        }
    }

    fn reassign(&self, visit: &mut Visit, actor: usize, rng: &mut Rng) {
        visit.actor = actor;
        for action in visit
            .entry
            .iter_mut()
            .chain(visit.field.iter_mut().flat_map(|f| &mut f.pattern))
        {
            if !self.supports(actor, &action.action) {
                *action = self.command(actor, rng);
            }
        }
    }
}

fn command(action: &str, rng: &mut Rng) -> Command {
    Command {
        action: action.into(),
        count: if action == "attack" {
            (1 + rng.index(6)) as u8
        } else {
            1
        },
        ready: matches!(action, "skill" | "burst"),
    }
}

impl Rotation {
    pub fn generate(catalog: &Catalog, rng: &mut Rng, field_actor: usize) -> Self {
        let mut order = [0, 1, 2, 3];
        for i in (1..4).rev() {
            order.swap(i, rng.index(i + 1));
        }
        let mut cycle: Vec<_> = order
            .into_iter()
            .map(|actor| catalog.visit(actor, rng, actor == field_actor))
            .collect();
        if rng.index(3) == 0 {
            let at = rng.index(cycle.len());
            cycle.insert(at, catalog.visit(rng.index(4), rng, true));
        }
        let opening = if rng.index(2) == 0 {
            vec![catalog.visit(rng.index(4), rng, false)]
        } else {
            Vec::new()
        };
        Self {
            active: order[0],
            opening,
            cycle,
        }
    }

    pub fn validate(&self) -> Result<(), String> {
        if self.active >= 4
            || self.cycle.is_empty()
            || self.cycle.len() > MAX_VISITS
            || self.opening.len() > 4
        {
            return Err("generated rotation size or active member is invalid".into());
        }
        for v in self.opening.iter().chain(&self.cycle) {
            if v.actor >= 4
                || !(1..=4).contains(&v.period)
                || v.phase >= v.period
                || v.entry.len() > MAX_ACTIONS
                || (v.entry.is_empty() && v.field.is_none())
            {
                return Err("generated visit is invalid".into());
            }
            if let Some(f) = &v.field
                && (!(30..=1200).contains(&f.frames) || f.pattern.is_empty() || f.pattern.len() > 6)
            {
                return Err("generated field window is invalid".into());
            }
            for a in v
                .entry
                .iter()
                .chain(v.field.iter().flat_map(|f| &f.pattern))
            {
                if !["attack", "charge", "skill", "burst", "dash", "jump"]
                    .contains(&a.action.as_str())
                    || !(1..=8).contains(&a.count)
                    || (a.action != "attack" && a.count != 1)
                    || (a.ready && !["skill", "burst"].contains(&a.action.as_str()))
                {
                    return Err("generated action is invalid".into());
                }
            }
        }
        Ok(())
    }

    pub fn gcsl(&self, m: &Manifest) -> String {
        let mut out = format!("active {};\n", m.members[self.active].key);
        for (i, visit) in self.opening.iter().enumerate() {
            render_visit(&mut out, visit, m, &format!("open{i}"));
        }
        for i in 0..self.cycle.len() {
            out.push_str(&format!("let generation_gate{i}=0;\n"));
        }
        out.push_str("while 1 {\nlet generation_start=f();\n");
        for (i, visit) in self.cycle.iter().enumerate() {
            out.push_str(&format!("if generation_gate{i} == {} {{\n", visit.phase));
            render_visit(&mut out, visit, m, &format!("visit{i}"));
            out.push_str(&format!("}}\ngeneration_gate{i}=generation_gate{i}+1;\nif generation_gate{i} >= {} {{ generation_gate{i}=0; }}\n", visit.period));
        }
        out.push_str("if f() == generation_start { wait(1); }\n}\n");
        out
    }

    /// Coarse behavior signature for reports, not a claim of semantic identity.
    pub fn structure(&self) -> String {
        self.cycle
            .iter()
            .map(|v| {
                format!(
                    "{}{}:{}/{}",
                    v.actor,
                    if v.field.is_some() { "F" } else { "Q" },
                    v.phase,
                    v.period
                )
            })
            .collect::<Vec<_>>()
            .join(",")
    }

    pub fn mutate(&self, catalog: &Catalog, rng: &mut Rng) -> (Self, String) {
        let op = rng.index(14);
        let i = rng.index(self.cycle.len());
        self.edit(catalog, rng, op, i)
    }

    fn edit(&self, catalog: &Catalog, rng: &mut Rng, op: usize, i: usize) -> (Self, String) {
        let mut p = self.clone();
        let label = match op {
            0 if p.cycle.len() < MAX_VISITS => {
                let actor = rng.index(4);
                let field = rng.index(2) == 0;
                p.cycle.insert(i, catalog.visit(actor, rng, field));
                "insert visit"
            }
            1 if p.cycle.len() > 1 => {
                p.cycle.remove(i);
                "delete visit"
            }
            2 => {
                let visit = p.cycle.remove(i);
                let at = rng.index(p.cycle.len() + 1);
                p.cycle.insert(at, visit);
                "relocate visit"
            }
            3 if p.cycle.len() < MAX_VISITS => {
                p.cycle.insert(i, p.cycle[i].clone());
                "duplicate visit"
            }
            4 => {
                let actor = (p.cycle[i].actor + 1 + rng.index(3)) % 4;
                catalog.reassign(&mut p.cycle[i], actor, rng);
                "change field ownership"
            }
            5 => {
                let v = &mut p.cycle[i];
                v.period = [1, 2, 3, 4][rng.index(4)];
                v.phase = rng.index(v.period as usize) as u8;
                "change visit period"
            }
            6 if p.cycle.len() < MAX_VISITS => {
                let v = &mut p.cycle[i];
                if v.entry.len() > 1 {
                    let entry = v.entry.split_off(v.entry.len() / 2);
                    let next = Visit {
                        entry,
                        field: v.field.take(),
                        ..v.clone()
                    };
                    p.cycle.insert(i + 1, next);
                } else if let Some(f) = &mut v.field
                    && f.frames >= 60
                {
                    let mut next = v.clone();
                    next.entry.clear();
                    next.field.as_mut().unwrap().frames /= 2;
                    v.field.as_mut().unwrap().frames -= next.field.as_ref().unwrap().frames;
                    p.cycle.insert(i + 1, next);
                }
                "split visit"
            }
            7 if i + 1 < p.cycle.len() => {
                let a = &p.cycle[i];
                let b = &p.cycle[i + 1];
                if a.actor == b.actor
                    && a.period == b.period
                    && a.phase == b.phase
                    && a.field.is_none()
                    && a.entry.len() + b.entry.len() <= MAX_ACTIONS
                {
                    let next = p.cycle.remove(i + 1);
                    p.cycle[i].entry.extend(next.entry);
                    p.cycle[i].field = next.field;
                }
                "merge visits"
            }
            8 => {
                let v = &mut p.cycle[i];
                if let Some(f) = &mut v.field {
                    f.frames = (i32::from(f.frames) + [-120, -30, 30, 120][rng.index(4)])
                        .clamp(30, 1200) as u16;
                    if rng.index(5) == 0 {
                        v.field = None;
                    }
                } else {
                    v.field = Some(catalog.field(v.actor, rng));
                }
                "change field length"
            }
            9 => {
                let v = &mut p.cycle[i];
                let actor = v.actor;
                let actions = if let Some(field) = &mut v.field
                    && rng.index(2) == 0
                {
                    &mut field.pattern
                } else {
                    &mut v.entry
                };
                edit_actions(actions, catalog, actor, rng);
                "edit action pattern"
            }
            10 => {
                let visit = p.cycle.remove(i);
                p.cycle.insert(0, visit);
                let v = &mut p.cycle[0];
                v.period = 1;
                v.phase = 0;
                let at = rng.index(p.cycle.len());
                let v = &mut p.cycle[at];
                v.field = Some(catalog.field(v.actor, rng));
                "compound order and field"
            }
            11 => {
                p.active = rng.index(4);
                "change active member"
            }
            12 => {
                if p.opening.len() < 4 && (p.opening.is_empty() || rng.index(2) == 0) {
                    p.opening.push(catalog.visit(rng.index(4), rng, false));
                } else if !p.opening.is_empty() {
                    let at = rng.index(p.opening.len());
                    p.opening.remove(at);
                }
                "change opening"
            }
            13 => {
                // A genuine change between a longer repeat and multiple shorter
                // opportunities: duplicate one visit, then change both gates.
                if p.cycle.len() < MAX_VISITS {
                    let mut next = p.cycle[i].clone();
                    p.cycle[i].period = 2;
                    p.cycle[i].phase = 0;
                    next.period = 2;
                    next.phase = 1;
                    if let Some(f) = &mut next.field {
                        f.frames = (f.frames / 2).max(30);
                    }
                    p.cycle.insert(i + 1, next);
                }
                "compound repeat structure"
            }
            _ => "bounded structural no-op",
        };
        if p.validate().is_err() {
            return (self.clone(), format!("{label}: invalid no-op"));
        }
        (p, format!("generated {label}"))
    }

    pub fn neighbors(&self, m: &Manifest) -> Vec<(Self, String)> {
        let Ok(catalog) = Catalog::new(m) else {
            return Vec::new();
        };
        let mut rng = Rng(0x47454e45524943);
        let mut seen = std::collections::BTreeSet::from([self.gcsl(m)]);
        let mut result = Vec::new();
        // Round-robin visits and operators, fixed RNG, independent of audit data.
        for op in 0..14 {
            for i in 0..self.cycle.len() {
                let (p, label) = self.edit(&catalog, &mut rng, op, i);
                if seen.insert(p.gcsl(m)) {
                    result.push((p, label));
                }
            }
        }
        result
    }
}

fn edit_actions(actions: &mut Vec<Command>, catalog: &Catalog, actor: usize, rng: &mut Rng) {
    if actions.is_empty() {
        actions.push(catalog.command(actor, rng));
        return;
    }
    let i = rng.index(actions.len());
    match rng.index(6) {
        0 if actions.len() < 6 => actions.insert(i, catalog.command(actor, rng)),
        1 if actions.len() > 1 => {
            actions.remove(i);
        }
        2 => actions[i] = catalog.command(actor, rng),
        3 if actions[i].action == "attack" => actions[i].count = (1 + rng.index(8)) as u8,
        4 if matches!(actions[i].action.as_str(), "skill" | "burst") => {
            actions[i].ready = !actions[i].ready
        }
        _ => {
            let j = rng.index(actions.len());
            actions.swap(i, j);
        }
    }
}

fn render_actions(out: &mut String, actions: &[Command], actor: &str) {
    for a in actions {
        if a.ready {
            out.push_str(&format!("if .{actor}.{}.ready {{\n", a.action));
        }
        out.push_str(&format!("{actor} {}:{};\n", a.action, a.count));
        if a.ready {
            out.push_str("}\n");
        }
    }
}

fn render_visit(out: &mut String, v: &Visit, m: &Manifest, id: &str) {
    let actor = &m.members[v.actor].key;
    out.push_str(&format!("{actor} swap;\n"));
    render_actions(out, &v.entry, actor);
    if let Some(f) = &v.field {
        out.push_str(&format!(
            "let {id}_end=f()+{};\nlet {id}_steps=0;\nwhile f() < {id}_end && {id}_steps < 64 {{\n",
            f.frames
        ));
        render_actions(out, &f.pattern, actor);
        out.push_str(&format!("{id}_steps={id}_steps+1;\nwait(1);\n}}\n"));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{evaluate::Evaluator, program::Program};

    #[test]
    fn generated_rotations_execute_full_fights_for_every_field_owner() {
        let m = crate::artifact::tests::fixed_party();
        let catalog = Catalog::new(&m).unwrap();
        let mut rng = Rng(37);
        for actor in 0..4 {
            let p = Rotation::generate(&catalog, &mut rng, actor);
            p.validate().unwrap();
            assert!(
                p.cycle
                    .iter()
                    .any(|v| v.actor == actor && v.field.is_some())
            );
            let source = Evaluator::config(&m, &Program::Generated(p));
            let parsed = gse::gcsl::parse(&source).unwrap();
            assert!(gse::check::unsupported(&parsed).is_empty());
            assert!(!source.contains("flins") && !source.contains("ineffa"));
            let fights = gse::api::run_iterations(&source, 150.0, 991, 0, 2).unwrap();
            assert!(
                fights
                    .iter()
                    .all(|s| s.frames == 27000 && s.dps.is_finite())
            );
        }
    }

    #[test]
    fn structural_edits_reach_new_orders_owners_periods_and_openings() {
        let m = crate::artifact::tests::fixed_party();
        let catalog = Catalog::new(&m).unwrap();
        let mut rng = Rng(91);
        let start = Rotation::generate(&catalog, &mut rng, 0);
        let mut p = start.clone();
        let mut changed_ops = std::collections::BTreeSet::new();
        let mut structures = std::collections::BTreeSet::new();
        for _ in 0..400 {
            let (next, label) = p.mutate(&catalog, &mut rng);
            next.validate().unwrap();
            let source = Evaluator::config(&m, &Program::Generated(next.clone()));
            let parsed = gse::gcsl::parse(&source).unwrap();
            assert!(gse::check::unsupported(&parsed).is_empty(), "{label}");
            if p != next {
                changed_ops.insert(label);
            }
            structures.insert(next.structure());
            p = next;
        }
        for op in [
            "insert visit",
            "delete visit",
            "relocate visit",
            "duplicate visit",
            "split visit",
            "merge visits",
            "change field ownership",
            "change visit period",
            "change field length",
            "edit action pattern",
            "change opening",
            "compound order and field",
            "compound repeat structure",
        ] {
            assert!(
                changed_ops.contains(&format!("generated {op}")),
                "unreached operator: {op}"
            );
        }
        assert!(structures.len() > 100);
        let neighbors = start.neighbors(&m);
        assert!(!neighbors.is_empty() && neighbors.len() <= 256);
        assert_eq!(neighbors, start.neighbors(&m));
    }

    #[test]
    fn guarded_only_patterns_and_skipped_cycles_cannot_spin_forever() {
        let m = crate::artifact::tests::fixed_party();
        let p = Rotation {
            active: 0,
            opening: vec![],
            cycle: vec![Visit {
                actor: 0,
                entry: vec![Command {
                    action: "skill".into(),
                    count: 1,
                    ready: true,
                }],
                field: Some(Field {
                    frames: 30,
                    pattern: vec![Command {
                        action: "skill".into(),
                        count: 1,
                        ready: true,
                    }],
                }),
                period: 4,
                phase: 3,
            }],
        };
        p.validate().unwrap();
        let source = Evaluator::config(&m, &Program::Generated(p));
        let fight = gse::api::run_iterations(&source, 150.0, 1, 0, 1).unwrap();
        assert_eq!(fight[0].frames, 27000);
    }
}
