# Baseline-free rotation discovery

The owner clarified that the optimizer must discover rotations for a new party,
not only edit a supplied rotation. This mode implements that discovery path.
It does not change the pinned simulator or the existing discovery eligibility
rules. The legacy baseline-derived path remains an explicit comparison.

## Experiment boundary

`search --from-scratch` reads a build manifest and never opens a baseline file.
`--baseline`, `--local-only` and `--restricted-domain` are incompatible with it.
Generated programs use no complete library cycle, party-specific sequence or
previous winner. Each of four initial families assigns a field opportunity to
a different member, shuffles visits and samples actions, repetition policies
and field lengths. Roles are hypotheses rather than fixed character labels.

Programs have separate opening and repeating visits. Each visit owns its
character, entry actions, optional timed field pattern and cycle period/phase.
Action availability is checked against the pinned engine. The initial grammar
covers default normal/charged attacks, skill, burst, dash and jump; arbitrary
action parameters and character-specific status predicates remain outside this
version. Engine support checks do not prove dynamic prerequisites or good play.
The real simulator determines the outcome, including waits and failures.

Macro mutations insert, remove, relocate, duplicate, split or merge visits,
change field ownership and periods, and make compound edits. Micro mutations
change action order/counts, readiness policies and field lengths. A charged
fresh-generation proposal can restart a family after a completed common block,
even with lower fitness; this is logged as `restart`, not a greedy improvement.
The best discovered candidate remains separate. Family scheduling and the
bounded archive preserve opportunities for multiple structures, not every
structure ever visited. Only one chain executes at a time.

The last quarter of each requested CPU cap uses a reproducible bounded local
neighborhood around the discovery-selected peak. Initial generation, support
checks, proposals, failed fights, repairs, restarts and promotions consume the
same discovery CPU cap. Saved RNG, pending proposals, chain states and polish
cursor support continuation. No short-horizon or low-DPS pruning is added.

The baseline fields in the compatible report schema refer to the first
generated starting program in this mode. Reports explicitly name that origin;
they are not comparisons against a library cycle. Keep an external good cycle
out of discovery and evaluate it only after selections are frozen. Independent
audit samples never guide discovery or polishing.

## Validation and next evidence

Check parser/engine support, full-fight execution, reachability of structural
edits, baseline-file independence and exact pending/RNG recovery. Local smoke
results establish execution, not broad search quality. Use fresh output
directories whenever implementation changes.

Before an effectiveness study, freeze the source, builds, budgets and seeds.
Use multiple genuinely held-out parties, repeated starts and equal CPU budgets;
report all failures and audit the search-selected result independently. Report
discovery and polish gains separately. Reference cycles are comparison-only
and are revealed after discovery. Full batch/cloud execution and an
unrestricted-optimality claim remain outside this implementation.
